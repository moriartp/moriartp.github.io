---
title: 'Mix up your reality'
media_order: ar-07.jpg
taxonomy:
    category:
        - mr
    tag:
        - MR
header_image_width: 1000
header_image_height: 300
summary:
    size: 60
    delimiter: ____
---

Yeah! Attorney-client privilege. I mean, that's a big one. That's something I provide for you. If I give up Pinkman, well, then you're gonna be asking, 'Ol' Saul gives 'em up pretty easy. What's to keep him from giving me up?' Y'see, so, then where's the trust? 

You want your criminal associate taken into police custody? We declare just enough so as to not arouse suspicion, so Walt's one time winnings becomes seed money for an investment. If you're committed enough, you can make any story work. I once told a woman I was Kevin Costner, and it worked because I believed it. 

It is not a disaster. It's not a disaster, alright? She's not going to the cops, she's not telling a living soul. You wanna know why? One word: blowback. If she blabs, it'll be a disaster - for her. That DEA brother-in-law? Screwed! You were right under his nose. He'll be lucky if they let him bust glue sniffers at the hobby shop. The kids? Paging Dr. Phil! 'My daddy's a drug dealer and my mommy turned him in!' And the house? Gone! The feds will come in and RICO her and the kids out on the street. Good luck arguing with them on that, noooo. It's not gonna happen. She's bluffing. And she knows it. 

Hello. Welcome. What a pleasure it is to have you. Just gonna call you Skyler if that's okay. It's a lovely name. It reminds me of the big, beautful sky. Walter always told me how lucky he was, prior to recent unfortunate events. Clearly his taste in women is the same as his taste in lawyers: only the very best with just the right amount of dirty. 