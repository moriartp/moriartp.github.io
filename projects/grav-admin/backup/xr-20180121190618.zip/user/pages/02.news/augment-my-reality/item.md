---
title: 'Augment My Reality'
media_order: 12.jpg
taxonomy:
    category:
        - ar
    tag:
        - AR
header_image_width: 1000
header_image_height: 200
---

Oh, my reality is so augmented. Bacon ipsum dolor amet bresaola pork chop t-bone salami corned beef venison pork loin doner chuck chicken. Beef ribs ham ribeye pork belly rump turducken cow turkey andouille filet mignon bresaola. Chuck strip steak pork leberkas, sirloin hamburger chicken pancetta. Tongue chuck short ribs, spare ribs pig drumstick beef ribs meatloaf filet mignon sirloin ham prosciutto alcatra. Turkey andouille pork kevin, burgdoggen venison fatback. Tongue biltong picanha pig flank salami burgdoggen leberkas bacon t-bone.

Cupim doner t-bone pastrami, prosciutto frankfurter turducken. Meatloaf tenderloin shankle, flank filet mignon spare ribs ham hock tri-tip. Fatback drumstick chuck kielbasa, tenderloin ground round sausage corned beef shank landjaeger tongue doner prosciutto sirloin venison. Beef ribs bresaola biltong, pig porchetta doner pancetta buffalo tenderloin venison pork chop drumstick. Rump short loin frankfurter, kielbasa beef ribs pork loin sausage pork chop shoulder. Meatloaf alcatra ham leberkas spare ribs landjaeger cow beef ribs shoulder rump tongue porchetta buffalo ribeye kevin. Buffalo cow chuck corned beef biltong picanha.

Burgdoggen alcatra frankfurter, bresaola swine t-bone jowl bacon drumstick sausage pancetta kielbasa meatloaf tri-tip pig. Turkey tenderloin spare ribs frankfurter tail porchetta. Ribeye shoulder filet mignon, pork loin picanha drumstick shankle jowl meatloaf capicola burgdoggen. Sausage fatback alcatra beef, shoulder tail meatloaf. Boudin pork shank tenderloin t-bone turkey flank doner ham ham hock chicken turducken ribeye kielbasa biltong.

Venison tri-tip ham hock meatloaf spare ribs, strip steak frankfurter prosciutto corned beef beef ribs sausage ribeye picanha kevin. Beef ribs meatball fatback doner, short ribs pastrami rump. Turducken porchetta shank meatloaf meatball, cow landjaeger chuck alcatra. Short loin picanha pig, tongue kevin ham pork loin tenderloin shankle alcatra flank kielbasa chuck. Fatback meatloaf capicola chicken, drumstick turducken flank kevin ribeye leberkas bresaola. Bacon beef frankfurter turducken biltong pastrami t-bone.

Prosciutto chuck biltong pork belly doner t-bone drumstick andouille burgdoggen shank filet mignon. Beef cupim short ribs meatball, corned beef pastrami chuck rump buffalo brisket drumstick picanha. Capicola strip steak kielbasa, pancetta ham hock pork belly leberkas tenderloin shoulder fatback salami. Burgdoggen bacon pork chop porchetta. Ball tip strip steak rump, shank bacon tri-tip tail.

Does your lorem ipsum text long for something a little meatier? Give our generator a try… it’s tasty!