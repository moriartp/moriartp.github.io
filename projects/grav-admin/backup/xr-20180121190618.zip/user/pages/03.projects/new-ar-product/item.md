---
title: 'New AR Product'
media_order: land-01.jpg
taxonomy:
    tag:
        - AR
---

Spicy jalapeno bacon ipsum dolor amet dolore cow reprehenderit, spare ribs short loin mollit non boudin ham. Ut porchetta esse sausage, drumstick pastrami fugiat strip steak qui nisi shankle ad. Velit enim doner, voluptate jowl short ribs spare ribs do landjaeger pariatur meatloaf eu. Pig tongue capicola chicken eiusmod sint. Flank quis kielbasa cow occaecat, bacon sirloin. Ut ad kielbasa hamburger brisket id occaecat tenderloin dolor ut chuck pastrami qui ham.

Cupidatat pancetta turducken picanha ea enim tongue sed veniam pork chop. Reprehenderit velit nisi pastrami. Beef ribs pork belly jerky, burgdoggen ut non short loin minim ad do leberkas beef turkey ea. Ball tip doner pariatur ad veniam. Qui id meatloaf ut beef aute fatback adipisicing ground round flank filet mignon. Pork incididunt corned beef pariatur ut deserunt venison quis mollit. Exercitation turkey biltong porchetta ad mollit tri-tip buffalo shankle t-bone occaecat corned beef strip steak salami.

Does your lorem ipsum text long for something a little meatier? Give our generator a try… it’s tasty!