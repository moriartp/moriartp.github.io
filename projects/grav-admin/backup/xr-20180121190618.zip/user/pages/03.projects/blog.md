---
title: Projects
content:
    items: '@self.children'
    limit: 5
    order:
        by: folder
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

# Projects

This is the body of **my new page** and I can easily use _Markdown_ syntax here. The various projects listed here represent a the wide range of product development and reseasrch being explored in this field. 