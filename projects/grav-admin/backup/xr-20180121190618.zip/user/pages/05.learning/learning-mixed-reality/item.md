---
title: 'Learning Mixed Reality '
taxonomy:
    category:
        - learning
    tag:
        - MR
        - vuforia
---

mixed reality tutorial: Vuforia

<iframe width=100% height="315" src="https://www.youtube.com/embed/6iaszALIaYs" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>