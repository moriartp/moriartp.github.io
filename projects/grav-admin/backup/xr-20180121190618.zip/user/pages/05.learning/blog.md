---
title: Learning
content:
    items: '@self.children'
    limit: 2
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

# Learning

This is the body of **my new page** and I can easily use _Markdown_ syntax here.

xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 xyz 456 