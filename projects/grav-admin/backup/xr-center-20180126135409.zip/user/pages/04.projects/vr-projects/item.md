---
title: 'My VR Project'
media_order: ar03.jpg
taxonomy:
    tag:
        - VR
---

check out this project. Ding, ding ding ding. Ding, ding ding ding ding ding DING, DING! DING! DING! DING DING DING DING! Ding, ding ding ding ding. DING. DING! 

Ding ding ding ding. Ding. Ding, ding ding ding ding. DING DING DING! Ding, ding ding, ding ding DING DING. DING. Ding, ding ding. Ding, ding ding ding. Ding. Ding ding ding ding. Ding, ding - ding ding. DING?! DING DING DING? Ding, ding ding... ding. Ding. DING. DING! 

DING ding ding ding ding. Ding. DING. DING DING DING. Ding, ding ding ding. DING. DING. DING! Ding, ding ding ding. Ding, ding ding ding, DING. DING. DING DING DING. Ding, ding ding. Ding, ding ding ding. Ding, ding ding. DING DING DING DING DING!! Ding, ding ding ding. Ding, ding ding ding diiiiiing. DING. 

Ding, ding ding ding. Ding, ding ding ding ding ding DING, DING! DING! DING! DING DING DING DING! Ding, ding ding ding ding. DING. DING!