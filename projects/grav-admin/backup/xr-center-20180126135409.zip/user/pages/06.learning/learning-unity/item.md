---
title: 'Learning Unity'
media_order: deadshot.jpg
taxonomy:
    category:
        - learning
    tag:
        - AR
        - VR
        - Unity
---

Unity is a game engine that has positioned itself at the center of VR and AR development sphere. Originally build as a gaming engine, it can be leverage for a variety of develop uses. A tutorial for unity development here
<iframe width=100% height="315" src="https://www.youtube.com/embed/Ep0rlBQRcVc" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>