---
title: Learning360
media_order: 36002.jpg
taxonomy:
    category:
        - learning
        - howto
    tag:
        - '360'
        - VR
content:
    items: '@self.children'
    limit: '5'
    order:
        by: date
        dir: desc
    pagination: '1'
    url_taxonomy_filters: '1'
---

This video will teach you to take 360 video with android. It it simple and available to anyone with an android device. It is highly accessible and easy to use.
<iframe width=100% height="315" src="https://www.youtube.com/embed/-JN8iex0yG8" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>