---
title: 'Learning Mixed Reality '
media_order: ar04.jpg
taxonomy:
    category:
        - learning
    tag:
        - MR
        - vuforia
---

In this article your will find a mixed reality video tutorial for a unity plugin called Vuforia. Vuforia is a good tool for developing augmented reality application. The article title may be missed leading but this is just sample article entry.

<iframe width=100% height="315" src="https://www.youtube.com/embed/6iaszALIaYs" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>