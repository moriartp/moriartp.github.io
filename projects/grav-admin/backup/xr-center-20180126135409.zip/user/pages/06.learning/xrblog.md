---
title: Learning
content:
    items: '@self.children'
    limit: '10'
    order:
        by: date
        dir: desc
    pagination: '1'
    url_taxonomy_filters: '1'
---

# Learning