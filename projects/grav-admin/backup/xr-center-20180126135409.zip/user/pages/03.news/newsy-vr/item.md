---
title: 'Newsy VR'
media_order: 3d03.jpg
taxonomy:
    tag:
        - VR
        - Parsons
        - AR
        - MR
---

To go on means going from here, means finding me, losing me, vanishing and beginning again, a stranger first, then little by little the same as always, in another place, where I shall say I have always been, of which I shall know nothing, being incapable of seeing, moving, thinking, speaking, but of which little by little, in spite of these handicaps, I shall begin to know something, just enough for it to turn out to be the same place as always, the same which seems made for me and does not want me, which I seem to want and do not want, take your choice, which spews me out or swallows me up, I’ll never know, which is perhaps merely the inside of my distant skull where once I wandered, now am fixed, lost for tininess, or straining against the walls, with my head, my hands, my feet, my back, and ever murmuring my old stories, my old story, as if it were the first time.