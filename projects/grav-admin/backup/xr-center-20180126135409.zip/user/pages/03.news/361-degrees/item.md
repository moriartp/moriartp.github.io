---
title: '361 degrees'
media_order: 36002.jpg
taxonomy:
    category:
        - '360'
    tag:
        - '360'
header_image_width: 1000
header_image_height: 300
summary:
    format: short
---

So I started from scratch. I made another, then another. And by the end of the semester, by like box number five, I had built this thing. You should have seen it. It was insane. I mean, I built it out of Peruvian walnut with inlaid zebrawood. It was fitted with pegs, no screws, I sanded it for days, until it was smooth as glass. Then I rubbed all the wood with tung oil so it was rich and dark. It even smelled good. You know, you put nose in it and breathed in, it was... it was perfect. 

What? Come on! Man, you're smart. You made poison out of beans, yo. Look, we got, we got an entire lab right here. Alright? How about you pick some of these chemicals and mix up some rocket fuel? That way you could just send up a signal flare. Or you make some kind of robot to get us help, or a homing device, or build a new battery, or... wait. No. What if we just take some stuff off of the RV and build it into something completely different? You know, like a... Like a dune buggy. That way, we can just dune buggy or... What? Hey? What is it? What? 

This is glass grade. I mean, you got... Jesus, you got crystals in here 2 inches, 3 inches long. This is pure glass. You're a damn artist! This is art, Mr. White! Yeah, that's the thing, y'know? Your scumbag brother-in-law took my rainy day fund. Oh yeah. And tell that douche bag brother-in-law of yours to go towards the light. 

Got something for me? Is this a five or an S? Jesus, how the hell do you spell street wrong - S T R E A T? Spooge. Not mad dog, not diesel... let me get this straight, you got jacked by a guy named Spooge? 