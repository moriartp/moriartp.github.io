---
title: 'XR Events'
media_order: post-it.jpg
taxonomy:
    category:
        - Event
    tag:
        - VR
        - Parsons
        - AR
        - MR
        - IT
---

orem ipsum dolor sit amet, consectetur adipiscing elit. In a tristique urna. Sed at scelerisque lacus. Nullam [congue metus id ex fringilla consectetur](xrcenter.newschool.edu). Ut ullamcorper eget est in fringilla. Donec condimentum lorem erat, vel fermentum nulla vehicula et. Proin nisl lacus, aliquam a tincidunt et, commodo a metus. Praesent venenatis hendrerit ante.

In et aliquam massa. Donec ut pretium leo. Quisque nunc turpis, blandit eget tempor vel, hendrerit et felis. Aliquam erat volutpat. Aliquam mattis sapien nec velit pharetra, a sollicitudin purus ornare. Curabitur eu urna vitae ante volutpat aliquet in at eros. Nullam eget turpis sodales, consectetur sem sit amet, auctor sem. Duis tempor sem in tincidunt ultricies. Etiam vitae egestas enim. Etiam facilisis dui convallis ornare hendrerit. Morbi dignissim lectus eu elementum iaculis. Suspendisse elementum, nunc a ultrices molestie, nisl tellus venenatis felis, eget elementum elit ligula sed mi. Curabitur sit amet lacus mollis, molestie lacus in, vulputate quam. Nulla eget turpis diam. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse neque sapien, faucibus sed finibus bibendum, bibendum at felis.

Proin dui velit, pretium ut tortor eu, ultrices ultricies est. Nunc eget pellentesque metus. Fusce nec pretium ligula. Cras ultrices ultricies mollis. Cras sagittis metus in odio scelerisque malesuada eget quis sem. Nam porta orci vel ullamcorper lacinia. Pellentesque vel lacus vitae nunc ornare vehicula. Suspendisse potenti. Vestibulum ultrices leo ac est porttitor, nec sagittis massa ultrices. Suspendisse commodo vehicula nulla quis viverra. Curabitur tincidunt a lacus et venenatis.

Suspendisse at vehicula est, a maximus lorem. Vivamus sagittis non leo a luctus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Suspendisse ut tempor justo. Sed aliquet, dui nec euismod rutrum, dui mi feugiat lorem, ut pharetra nunc ligula eu ligula. Nam eget venenatis nibh. Nullam id diam dui. Quisque suscipit quis est ac interdum. Nullam eget metus nisl.

Proin blandit quam ut libero accumsan, non placerat nibh sodales. Vivamus tincidunt ligula lorem, id hendrerit augue tincidunt eu. Nullam cursus arcu eros, a gravida ligula volutpat ac. Nam convallis convallis mattis. Proin eu dapibus purus. Sed efficitur justo a leo finibus, nec euismod eros faucibus. Ut rutrum vitae augue eu dignissim. Nullam lacinia mi vitae nisl tincidunt, eu interdum risus scelerisque. Nulla auctor scelerisque augue sed sollicitudin. Aliquam sit amet lorem vel dui rhoncus ultricies sed non dolor. Nunc bibendum sapien ipsum, vel euismod magna auctor eget. Curabitur eu urna et velit pretium malesuada non sit amet sem.