---
title: Team
content:
    items: '@self.children'
    limit: '5'
    order:
        by: date
        dir: desc
    pagination: '1'
    url_taxonomy_filters: '1'
---

# Team

The XReality Center brings together people working in virtual, aumented and mixed reality platforms from across the university. A wide range of persons from the faculty, staff, and student populations maintain affiliations.