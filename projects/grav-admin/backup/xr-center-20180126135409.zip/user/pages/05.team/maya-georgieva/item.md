---
title: 'Maya Georgieva'
media_order: wood-grain.jpg
---

Maya Georgieva is the Director of Digital Learning at The New School. At the XReality Center, she leads in the areas of Immersive Learning and Research. In 2015 she co-founded Digital Bodies a consulting group focusing on VR/AR/MR and their impact on education and society. She has facilitated master classes and talks on Immersive Storytelling, VR/AR/MR and New Media Narratives, Innovation in Higher Education and the Future of Learning.