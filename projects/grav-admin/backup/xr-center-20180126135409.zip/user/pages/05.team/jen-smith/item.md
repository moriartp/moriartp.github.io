---
title: 'Jen Smith'
media_order: jensmith.jpg
taxonomy:
    category:
        - Staff
    tag:
        - IT
---

Jennifer is the director of IT project management in the IT department at The New School. She has been involved in emerging technology initiatives starting with the advent of digital music technology at Berklee College of Music in Boston, MA. As a web and DVD media producer in the early dot com days in NYC, she transitioned to the New School to work in academic technology and now manages IT project initiatives.