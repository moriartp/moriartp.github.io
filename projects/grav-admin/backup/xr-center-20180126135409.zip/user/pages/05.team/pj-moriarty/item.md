---
title: 'PJ Moriarty'
media_order: b034.jpg
taxonomy:
    category:
        - Staff
    tag:
        - IT
        - Parsons
---

A certified Project Management Professional (PMP)® and member of The New School's Information Technology Project Management Office, PJ has conducted graduate research on both the organizational impacts of disruptive technology emergence, and the design affordances of augented reality as a vehicle for data visualization. His career softball batting average is .387.